(globalThis["TURBOPACK"] || (globalThis["TURBOPACK"] = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/navbar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navbar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
const links = [
    {
        href: "/",
        label: "Home",
        icon: "🏠"
    },
    {
        href: "/woodcutting",
        label: "Woodcutting",
        icon: "🪓"
    },
    {
        href: "/mining",
        label: "Mining",
        icon: "⛏️"
    },
    {
        href: "/inventory",
        label: "Inventory",
        icon: "🎒"
    },
    {
        href: "/shop",
        label: "Shop",
        icon: "🏪"
    }
];
function Navbar() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    let bgColor = "bg-slate-950";
    if (pathname === "/woodcutting") {
        bgColor = "bg-green-950";
    } else if (pathname === "/mining") {
        bgColor = "bg-stone-950";
    } else if (pathname === "/shop") {
        bgColor = "bg-violet-950";
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
        className: `sticky top-0 z-10 flex items-center justify-between px-6 py-3 ${bgColor}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm font-bold tracking-widest text-white/40 uppercase",
                children: "⚔️ IdleGame"
            }, void 0, false, {
                fileName: "[project]/app/components/navbar.tsx",
                lineNumber: 28,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
                className: "flex items-center gap-1",
                children: links.map((link)=>{
                    const isActive = pathname === link.href;
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: link.href,
                            className: `flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium transition-colors ${isActive ? "bg-white/10 text-white" : "text-white/50 hover:bg-white/5 hover:text-white/80"}`,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: link.icon
                                }, void 0, false, {
                                    fileName: "[project]/app/components/navbar.tsx",
                                    lineNumber: 44,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    children: link.label
                                }, void 0, false, {
                                    fileName: "[project]/app/components/navbar.tsx",
                                    lineNumber: 45,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/navbar.tsx",
                            lineNumber: 36,
                            columnNumber: 15
                        }, this)
                    }, link.href, false, {
                        fileName: "[project]/app/components/navbar.tsx",
                        lineNumber: 35,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/app/components/navbar.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/navbar.tsx",
        lineNumber: 27,
        columnNumber: 5
    }, this);
}
_s(Navbar, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c = Navbar;
var _c;
__turbopack_context__.k.register(_c, "Navbar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/lib/resources.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DEFAULT_TOOLS",
    ()=>DEFAULT_TOOLS,
    "ROCKS",
    ()=>ROCKS,
    "SHOP_TOOLS",
    ()=>SHOP_TOOLS,
    "TREES",
    ()=>TREES
]);
const DEFAULT_TOOLS = {
    bronzeAxe: false,
    ironAxe: false,
    bronzePickaxe: false,
    ironPickaxe: false
};
const TREES = [
    {
        id: "tree",
        name: "Tree",
        icon: "🌲",
        xpPerItem: 25,
        speed: 2,
        toolReq: null,
        itemKey: "wcLogs",
        goldPer: 2
    },
    {
        id: "oak",
        name: "Oak",
        icon: "🌳",
        xpPerItem: 60,
        speed: 1.5,
        toolReq: "bronzeAxe",
        itemKey: "wcOakLogs",
        goldPer: 8
    },
    {
        id: "willow",
        name: "Willow",
        icon: "🌿",
        xpPerItem: 110,
        speed: 1,
        toolReq: "ironAxe",
        itemKey: "wcWillowLogs",
        goldPer: 18
    }
];
const ROCKS = [
    {
        id: "rock",
        name: "Rock",
        icon: "🪨",
        xpPerItem: 35,
        speed: 1.5,
        toolReq: null,
        itemKey: "miningOres",
        goldPer: 5
    },
    {
        id: "copper",
        name: "Copper",
        icon: "🟤",
        xpPerItem: 70,
        speed: 1.2,
        toolReq: "bronzePickaxe",
        itemKey: "miningCopperOres",
        goldPer: 15
    },
    {
        id: "iron",
        name: "Iron",
        icon: "⚙️",
        xpPerItem: 130,
        speed: 0.8,
        toolReq: "ironPickaxe",
        itemKey: "miningIronOres",
        goldPer: 30
    }
];
const SHOP_TOOLS = [
    {
        id: "bronzeAxe",
        name: "Bronze Axe",
        icon: "🪓",
        cost: 200,
        unlocks: "Oak trees",
        skill: "woodcutting"
    },
    {
        id: "ironAxe",
        name: "Iron Axe",
        icon: "🪓",
        cost: 1000,
        unlocks: "Willow trees",
        skill: "woodcutting"
    },
    {
        id: "bronzePickaxe",
        name: "Bronze Pickaxe",
        icon: "⛏️",
        cost: 200,
        unlocks: "Copper rocks",
        skill: "mining"
    },
    {
        id: "ironPickaxe",
        name: "Iron Pickaxe",
        icon: "⛏️",
        cost: 1000,
        unlocks: "Iron rocks",
        skill: "mining"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/context/GameContext.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GameProvider",
    ()=>GameProvider,
    "useGame",
    ()=>useGame
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$resources$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/lib/resources.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
function getResource(skill, selectedId) {
    const list = skill === "woodcutting" ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$resources$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TREES"] : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$resources$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ROCKS"];
    return list.find((r)=>r.id === selectedId) ?? list[0];
}
function secsPerItem(resource) {
    return 100 / resource.speed * 0.05;
}
const GameContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(null);
function useGame() {
    _s();
    const ctx = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(GameContext);
    if (!ctx) throw new Error("useGame must be used inside GameProvider");
    return ctx;
}
_s(useGame, "/dMy7t63NXD4eYACoT93CePwGrg=");
function readFromStorage() {
    return {
        wcXp: Number(localStorage.getItem("wc_xp")) || 0,
        wcLogs: Number(localStorage.getItem("wc_logs")) || 0,
        miningXp: Number(localStorage.getItem("mining_xp")) || 0,
        miningOres: Number(localStorage.getItem("mining_ores")) || 0,
        gold: Number(localStorage.getItem("gold")) || 0,
        tools: JSON.parse(localStorage.getItem("tools") || "null") ?? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$resources$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TOOLS"],
        inventory: JSON.parse(localStorage.getItem("inventory") || "{}")
    };
}
function writeToStorage(s) {
    localStorage.setItem("wc_xp", String(s.wcXp));
    localStorage.setItem("wc_logs", String(s.wcLogs));
    localStorage.setItem("mining_xp", String(s.miningXp));
    localStorage.setItem("mining_ores", String(s.miningOres));
    localStorage.setItem("gold", String(s.gold));
    localStorage.setItem("tools", JSON.stringify(s.tools));
    localStorage.setItem("inventory", JSON.stringify(s.inventory));
}
let nextToastId = 0;
function GameProvider({ children }) {
    _s1();
    const [state, setState] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])({
        wcXp: 0,
        wcLogs: 0,
        miningXp: 0,
        miningOres: 0,
        gold: 0,
        tools: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$resources$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TOOLS"],
        inventory: {}
    });
    const [activeSkill, setActiveSkill] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [progress, setProgress] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [selectedTree, setSelectedTree] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("tree");
    const [selectedRock, setSelectedRock] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("rock");
    const [toasts, setToasts] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [loaded, setLoaded] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Load from localStorage + offline progress
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameProvider.useEffect": ()=>{
            const saved = readFromStorage();
            const storedTree = localStorage.getItem("selected_tree") || "tree";
            const storedRock = localStorage.getItem("selected_rock") || "rock";
            setSelectedTree(storedTree);
            setSelectedRock(storedRock);
            const skill = localStorage.getItem("active_skill");
            const startTime = Number(localStorage.getItem("active_skill_start")) || 0;
            let final = {
                ...saved
            };
            if (skill && startTime > 0) {
                const resourceId = skill === "woodcutting" ? storedTree : storedRock;
                const resource = getResource(skill, resourceId);
                const elapsed = (Date.now() - startTime) / 1000;
                const items = Math.floor(elapsed / secsPerItem(resource));
                const xp = items * resource.xpPerItem;
                if (skill === "woodcutting") {
                    final.wcXp += xp;
                    final.wcLogs += items;
                } else {
                    final.miningXp += xp;
                    final.miningOres += items;
                }
                final.inventory = {
                    ...final.inventory
                };
                final.inventory[resourceId] = (final.inventory[resourceId] || 0) + items;
                writeToStorage(final);
                localStorage.setItem("active_skill_start", String(Date.now()));
                setActiveSkill(skill);
                if (items > 0) {
                    pushToast(skill === "woodcutting" ? "🪵" : "🪨", `+${items} ${resource.name} (offline)`);
                }
            }
            setState(final);
            setLoaded(true);
        }
    }["GameProvider.useEffect"], []);
    // Persist to localStorage
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameProvider.useEffect": ()=>{
            if (!loaded) return;
            writeToStorage(state);
        }
    }["GameProvider.useEffect"], [
        state,
        loaded
    ]);
    // Game loop — restarts when active skill or selected resource changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "GameProvider.useEffect": ()=>{
            if (!activeSkill) return;
            const resourceId = activeSkill === "woodcutting" ? selectedTree : selectedRock;
            const resource = getResource(activeSkill, resourceId);
            const { speed, xpPerItem } = resource;
            const itemIcon = activeSkill === "woodcutting" ? "🪵" : "🪨";
            const interval = setInterval({
                "GameProvider.useEffect.interval": ()=>{
                    setProgress({
                        "GameProvider.useEffect.interval": (prev)=>{
                            const next = prev + speed;
                            if (next >= 100) {
                                setState({
                                    "GameProvider.useEffect.interval": (s)=>{
                                        const newState = {
                                            ...s,
                                            inventory: {
                                                ...s.inventory
                                            }
                                        };
                                        newState.inventory[resourceId] = (newState.inventory[resourceId] || 0) + 1;
                                        if (activeSkill === "woodcutting") {
                                            newState.wcXp += xpPerItem;
                                            newState.wcLogs += 1;
                                        } else {
                                            newState.miningXp += xpPerItem;
                                            newState.miningOres += 1;
                                        }
                                        return newState;
                                    }
                                }["GameProvider.useEffect.interval"]);
                                pushToast(itemIcon, `+1 ${resource.name}`);
                                return 0;
                            }
                            return next;
                        }
                    }["GameProvider.useEffect.interval"]);
                }
            }["GameProvider.useEffect.interval"], 50);
            return ({
                "GameProvider.useEffect": ()=>clearInterval(interval)
            })["GameProvider.useEffect"];
        }
    }["GameProvider.useEffect"], [
        activeSkill,
        selectedTree,
        selectedRock
    ]);
    function pushToast(icon, text) {
        const id = ++nextToastId;
        setToasts((prev)=>[
                ...prev,
                {
                    id,
                    icon,
                    text
                }
            ]);
        setTimeout(()=>setToasts((prev)=>prev.filter((t)=>t.id !== id)), 2500);
    }
    function startSkill(skill) {
        setProgress(0);
        setActiveSkill(skill);
        localStorage.setItem("active_skill", skill);
        localStorage.setItem("active_skill_start", String(Date.now()));
    }
    function stopSkill() {
        setProgress(0);
        setActiveSkill(null);
        localStorage.removeItem("active_skill");
        localStorage.removeItem("active_skill_start");
    }
    function selectResource(skill, resourceId) {
        setProgress(0);
        if (skill === "woodcutting") {
            setSelectedTree(resourceId);
            localStorage.setItem("selected_tree", resourceId);
        } else {
            setSelectedRock(resourceId);
            localStorage.setItem("selected_rock", resourceId);
        }
    }
    function buyTool(toolId) {
        const tool = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$lib$2f$resources$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SHOP_TOOLS"].find((t)=>t.id === toolId);
        if (!tool) return;
        setState((s)=>{
            if (s.gold < tool.cost || s.tools[toolId]) return s;
            return {
                ...s,
                gold: s.gold - tool.cost,
                tools: {
                    ...s.tools,
                    [toolId]: true
                }
            };
        });
    }
    function sell(item, amount, goldPer) {
        setState((s)=>{
            const qty = Math.min(s[item], amount);
            return {
                ...s,
                [item]: s[item] - qty,
                gold: s.gold + qty * goldPer
            };
        });
    }
    function sellItem(itemId, amount, goldPer) {
        setState((s)=>{
            const currentQty = s.inventory[itemId] || 0;
            if (currentQty <= 0) return s;
            const qty = Math.min(currentQty, amount);
            return {
                ...s,
                inventory: {
                    ...s.inventory,
                    [itemId]: currentQty - qty
                },
                gold: s.gold + qty * goldPer
            };
        });
    }
    function addGold(amount) {
        setState((s)=>({
                ...s,
                gold: s.gold + amount
            }));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(GameContext.Provider, {
        value: {
            state,
            activeSkill,
            progress,
            selectedTree,
            selectedRock,
            toasts,
            loaded,
            startSkill,
            stopSkill,
            selectResource,
            buyTool,
            sell,
            sellItem,
            addGold
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/context/GameContext.tsx",
        lineNumber: 235,
        columnNumber: 5
    }, this);
}
_s1(GameProvider, "EGS6bp5OAhOxk9SqtOWjAGq5BY8=");
_c = GameProvider;
var _c;
__turbopack_context__.k.register(_c, "GameProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/notifications.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Notifications
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$GameContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/context/GameContext.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function Notifications() {
    _s();
    const { toasts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$GameContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGame"])();
    if (toasts.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "pointer-events-none fixed bottom-6 right-6 z-50 flex flex-col items-end gap-2",
        children: toasts.map((toast)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2.5 rounded-full border border-white/10 bg-zinc-900/95 px-4 py-2 text-sm font-medium text-white shadow-2xl backdrop-blur-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: toast.icon
                    }, void 0, false, {
                        fileName: "[project]/app/components/notifications.tsx",
                        lineNumber: 17,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: toast.text
                    }, void 0, false, {
                        fileName: "[project]/app/components/notifications.tsx",
                        lineNumber: 18,
                        columnNumber: 11
                    }, this)
                ]
            }, toast.id, true, {
                fileName: "[project]/app/components/notifications.tsx",
                lineNumber: 13,
                columnNumber: 9
            }, this))
    }, void 0, false, {
        fileName: "[project]/app/components/notifications.tsx",
        lineNumber: 11,
        columnNumber: 5
    }, this);
}
_s(Notifications, "6GkrZ+zUgqAzDtGjdIsgEyDM8vU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$GameContext$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGame"]
    ];
});
_c = Notifications;
var _c;
__turbopack_context__.k.register(_c, "Notifications");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_0z1tb6x._.js.map